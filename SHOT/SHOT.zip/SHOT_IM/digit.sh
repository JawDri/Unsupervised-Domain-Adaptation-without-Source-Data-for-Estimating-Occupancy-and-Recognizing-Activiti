~/anaconda3/envs/pytorch/bin/python uda_digit.py --dset m2u --gpu_id 0 --cls_par 0.1 --output ckps_digits
~/anaconda3/envs/pytorch/bin/python uda_digit.py --dset u2m --gpu_id 0 --cls_par 0.1 --output ckps_digits
~/anaconda3/envs/pytorch/bin/python uda_digit.py --dset s2m --gpu_id 0 --cls_par 0.1 --output ckps_digits