from .svhn import *
from .mnist import *
from .usps import *